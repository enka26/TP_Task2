#!bin/usr/python
import os
p = os.path.dirname(os.path.abspath(__file__))+ "/index.h"

file = open(p,"w")
file.close()

